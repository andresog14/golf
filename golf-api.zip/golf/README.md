# Golf API

API para gestionar marcadores de golf y calcular hándicaps.

## Instalación

1. Clona este repositorio.
2. Instala las dependencias usando `npm install`.
3. Ejecuta la aplicación con `npm start`.

## Rutas de la API

- `GET /scores`: Obtiene todos los marcadores.
- `POST /scores`: Crea un nuevo marcador.
